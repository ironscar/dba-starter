--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE student_tracker;
--
-- Name: student_tracker; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE student_tracker WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE student_tracker OWNER TO postgres;

\connect student_tracker

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: myschema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA myschema;


ALTER SCHEMA myschema OWNER TO postgres;

--
-- Name: audit_log(); Type: FUNCTION; Schema: myschema; Owner: springstudent
--

CREATE FUNCTION myschema.audit_log() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
	insert into myschema.task_audit (task_id, entry_date, operation)
	values (new.task_id, current_date, 'INSERT');
	return new;
end; 
$$;


ALTER FUNCTION myschema.audit_log() OWNER TO springstudent;

--
-- Name: event_trigger_function(); Type: FUNCTION; Schema: myschema; Owner: springstudent
--

CREATE FUNCTION myschema.event_trigger_function() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
begin
	raise info 'Event = %, Tag = %', tg_event, tg_tag;
end $$;


ALTER FUNCTION myschema.event_trigger_function() OWNER TO springstudent;

--
-- Name: inserter(); Type: PROCEDURE; Schema: myschema; Owner: springstudent
--

CREATE PROCEDURE myschema.inserter()
    LANGUAGE plpgsql
    AS $$
begin
	truncate table myschema.index_trial_tasks;
	for i in 1..1000 loop
		insert into myschema.index_trial_tasks values (
			i, 'tt' || i, 100 + i
		);
	end loop;
	commit;
end
$$;


ALTER PROCEDURE myschema.inserter() OWNER TO springstudent;

--
-- Name: inserter2(); Type: FUNCTION; Schema: myschema; Owner: springstudent
--

CREATE FUNCTION myschema.inserter2() RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
	truncate table myschema.index_trial_tasks;
	for i in 1..1000 loop
		insert into myschema.index_trial_tasks values (
			i, 'tt' || i, 100 + i
		);
	end loop;
end
$$;


ALTER FUNCTION myschema.inserter2() OWNER TO springstudent;

--
-- Name: parameterized_returner(integer); Type: FUNCTION; Schema: myschema; Owner: springstudent
--

CREATE FUNCTION myschema.parameterized_returner(times integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	counter int = 1;
begin
	counter = counter * times;
	return counter;
end;
$$;


ALTER FUNCTION myschema.parameterized_returner(times integer) OWNER TO springstudent;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: index_trial_tasks; Type: TABLE; Schema: myschema; Owner: springstudent
--

CREATE TABLE myschema.index_trial_tasks (
    task_id integer NOT NULL,
    task_title character varying(20) NOT NULL,
    user_id integer
);


ALTER TABLE myschema.index_trial_tasks OWNER TO springstudent;

--
-- Name: task_audit; Type: TABLE; Schema: myschema; Owner: springstudent
--

CREATE TABLE myschema.task_audit (
    log_id integer NOT NULL,
    task_id integer NOT NULL,
    entry_date date,
    operation character varying(10)
);


ALTER TABLE myschema.task_audit OWNER TO springstudent;

--
-- Name: task_audit_log_id_seq; Type: SEQUENCE; Schema: myschema; Owner: springstudent
--

CREATE SEQUENCE myschema.task_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE myschema.task_audit_log_id_seq OWNER TO springstudent;

--
-- Name: task_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: myschema; Owner: springstudent
--

ALTER SEQUENCE myschema.task_audit_log_id_seq OWNED BY myschema.task_audit.log_id;


--
-- Name: tasks; Type: TABLE; Schema: myschema; Owner: springstudent
--

CREATE TABLE myschema.tasks (
    task_id integer NOT NULL,
    task_name character varying(20) NOT NULL,
    task_desc character varying(20) NOT NULL,
    task_type character varying(10) DEFAULT NULL::character varying,
    parent integer
);


ALTER TABLE myschema.tasks OWNER TO springstudent;

--
-- Name: tasks_archive; Type: TABLE; Schema: myschema; Owner: springstudent
--

CREATE TABLE myschema.tasks_archive (
    task_id integer NOT NULL,
    task_name character varying(20) NOT NULL,
    task_desc character varying(20) NOT NULL,
    task_type character varying(10) DEFAULT NULL::character varying,
    parent integer
);


ALTER TABLE myschema.tasks_archive OWNER TO springstudent;

--
-- Name: authorities; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.authorities (
    username character varying(50) NOT NULL,
    authority character varying(50) NOT NULL
);


ALTER TABLE public.authorities OWNER TO springstudent;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.counter (
    count bigint
);


ALTER TABLE public.counter OWNER TO springstudent;

--
-- Name: custom_authorities; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.custom_authorities (
    userid character varying(50) NOT NULL,
    role character varying(50) NOT NULL
);


ALTER TABLE public.custom_authorities OWNER TO springstudent;

--
-- Name: custom_space_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_space_table (
    id integer,
    name character varying(10)
);


ALTER TABLE public.custom_space_table OWNER TO postgres;

--
-- Name: custom_users; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.custom_users (
    userid character varying(50) NOT NULL,
    pwd character varying(100) NOT NULL,
    age integer NOT NULL,
    enabled character(1) NOT NULL
);


ALTER TABLE public.custom_users OWNER TO springstudent;

--
-- Name: greeting; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.greeting (
    id integer NOT NULL,
    message character varying(45) NOT NULL,
    student_id integer NOT NULL
);


ALTER TABLE public.greeting OWNER TO springstudent;

--
-- Name: greeting_id_seq; Type: SEQUENCE; Schema: public; Owner: springstudent
--

CREATE SEQUENCE public.greeting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.greeting_id_seq OWNER TO springstudent;

--
-- Name: greeting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: springstudent
--

ALTER SEQUENCE public.greeting_id_seq OWNED BY public.greeting.id;


--
-- Name: student; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.student (
    id integer NOT NULL,
    first_name character varying(45) DEFAULT NULL::character varying,
    last_name character varying(45) DEFAULT NULL::character varying,
    email character varying(45) DEFAULT NULL::character varying
);


ALTER TABLE public.student OWNER TO springstudent;

--
-- Name: student_id_seq; Type: SEQUENCE; Schema: public; Owner: springstudent
--

CREATE SEQUENCE public.student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_id_seq OWNER TO springstudent;

--
-- Name: student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: springstudent
--

ALTER SEQUENCE public.student_id_seq OWNED BY public.student.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: springstudent
--

CREATE TABLE public.users (
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    enabled integer NOT NULL
);


ALTER TABLE public.users OWNER TO springstudent;

--
-- Name: task_audit log_id; Type: DEFAULT; Schema: myschema; Owner: springstudent
--

ALTER TABLE ONLY myschema.task_audit ALTER COLUMN log_id SET DEFAULT nextval('myschema.task_audit_log_id_seq'::regclass);


--
-- Name: greeting id; Type: DEFAULT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.greeting ALTER COLUMN id SET DEFAULT nextval('public.greeting_id_seq'::regclass);


--
-- Name: student id; Type: DEFAULT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.student ALTER COLUMN id SET DEFAULT nextval('public.student_id_seq'::regclass);


--
-- Data for Name: index_trial_tasks; Type: TABLE DATA; Schema: myschema; Owner: springstudent
--

COPY myschema.index_trial_tasks (task_id, task_title, user_id) FROM stdin;
\.
COPY myschema.index_trial_tasks (task_id, task_title, user_id) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: task_audit; Type: TABLE DATA; Schema: myschema; Owner: springstudent
--

COPY myschema.task_audit (log_id, task_id, entry_date, operation) FROM stdin;
\.
COPY myschema.task_audit (log_id, task_id, entry_date, operation) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: myschema; Owner: springstudent
--

COPY myschema.tasks (task_id, task_name, task_desc, task_type, parent) FROM stdin;
\.
COPY myschema.tasks (task_id, task_name, task_desc, task_type, parent) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: tasks_archive; Type: TABLE DATA; Schema: myschema; Owner: springstudent
--

COPY myschema.tasks_archive (task_id, task_name, task_desc, task_type, parent) FROM stdin;
\.
COPY myschema.tasks_archive (task_id, task_name, task_desc, task_type, parent) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: authorities; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.authorities (username, authority) FROM stdin;
\.
COPY public.authorities (username, authority) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.counter (count) FROM stdin;
\.
COPY public.counter (count) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: custom_authorities; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.custom_authorities (userid, role) FROM stdin;
\.
COPY public.custom_authorities (userid, role) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: custom_space_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_space_table (id, name) FROM stdin;
\.
COPY public.custom_space_table (id, name) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: custom_users; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.custom_users (userid, pwd, age, enabled) FROM stdin;
\.
COPY public.custom_users (userid, pwd, age, enabled) FROM '$$PATH$$/3474.dat';

--
-- Data for Name: greeting; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.greeting (id, message, student_id) FROM stdin;
\.
COPY public.greeting (id, message, student_id) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.student (id, first_name, last_name, email) FROM stdin;
\.
COPY public.student (id, first_name, last_name, email) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: springstudent
--

COPY public.users (username, password, enabled) FROM stdin;
\.
COPY public.users (username, password, enabled) FROM '$$PATH$$/3473.dat';

--
-- Name: task_audit_log_id_seq; Type: SEQUENCE SET; Schema: myschema; Owner: springstudent
--

SELECT pg_catalog.setval('myschema.task_audit_log_id_seq', 45, true);


--
-- Name: greeting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: springstudent
--

SELECT pg_catalog.setval('public.greeting_id_seq', 5, true);


--
-- Name: student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: springstudent
--

SELECT pg_catalog.setval('public.student_id_seq', 7, true);


--
-- Name: task_audit task_audit_pkey; Type: CONSTRAINT; Schema: myschema; Owner: springstudent
--

ALTER TABLE ONLY myschema.task_audit
    ADD CONSTRAINT task_audit_pkey PRIMARY KEY (log_id);


--
-- Name: tasks_archive tasks_archive_pkey; Type: CONSTRAINT; Schema: myschema; Owner: springstudent
--

ALTER TABLE ONLY myschema.tasks_archive
    ADD CONSTRAINT tasks_archive_pkey PRIMARY KEY (task_id);


--
-- Name: tasks tasks_sort_key; Type: CONSTRAINT; Schema: myschema; Owner: springstudent
--

ALTER TABLE ONLY myschema.tasks
    ADD CONSTRAINT tasks_sort_key UNIQUE (task_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authorities authorities_username_authority_key; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.authorities
    ADD CONSTRAINT authorities_username_authority_key UNIQUE (username, authority);


--
-- Name: custom_authorities custom_authorities_userid_role_key; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.custom_authorities
    ADD CONSTRAINT custom_authorities_userid_role_key UNIQUE (userid, role);


--
-- Name: custom_users custom_users_pkey; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.custom_users
    ADD CONSTRAINT custom_users_pkey PRIMARY KEY (userid);


--
-- Name: greeting greeting_pkey; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.greeting
    ADD CONSTRAINT greeting_pkey PRIMARY KEY (id);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- Name: myschema_index3; Type: INDEX; Schema: myschema; Owner: springstudent
--

CREATE INDEX myschema_index3 ON myschema.index_trial_tasks USING btree (lower((task_title)::text));


--
-- Name: authorities authorities_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.authorities
    ADD CONSTRAINT authorities_username_fkey FOREIGN KEY (username) REFERENCES public.users(username);


--
-- Name: custom_authorities custom_authorities_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.custom_authorities
    ADD CONSTRAINT custom_authorities_userid_fkey FOREIGN KEY (userid) REFERENCES public.custom_users(userid);


--
-- Name: greeting greeting_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: springstudent
--

ALTER TABLE ONLY public.greeting
    ADD CONSTRAINT greeting_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(id);


--
-- Name: SCHEMA myschema; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA myschema TO springstudent;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO springstudent;


--
-- PostgreSQL database dump complete
--

